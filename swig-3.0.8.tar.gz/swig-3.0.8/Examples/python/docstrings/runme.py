# file: runme.py

import example

print "example.Foo.bar.__doc__  =", repr(example.Foo.bar.__doc__), "(Should be 'No comment')"
