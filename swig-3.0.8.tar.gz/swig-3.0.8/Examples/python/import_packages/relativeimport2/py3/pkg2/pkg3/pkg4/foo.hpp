#ifndef PY3_PKG2_PKG3_PKG4
#define PY3_PKG2_PKG3_PKG4
struct Pkg4_Foo {};
#endif /* PY3_PKG2_PKG3_PKG4 */
