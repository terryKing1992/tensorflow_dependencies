#ifndef PY3_PKG2_FOO_HPP
#define PY3_PKG2_FOO_HPP
struct Pkg2_Foo {};
#endif /* PY3_PKG2_FOO_HPP */
