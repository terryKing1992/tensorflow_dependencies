from struct_initialization import *

if cvar.instanceC1.x != 10:
    raise RuntimeError

if cvar.instanceD1.x != 10:
    raise RuntimeError

if cvar.instanceD2.x != 20:
    raise RuntimeError

if cvar.instanceD3.x != 30:
    raise RuntimeError

if cvar.instanceE1.x != 1:
    raise RuntimeError

if cvar.instanceF1.x != 1:
    raise RuntimeError
