=====================
TableGen Fundamentals
=====================

Moved
=====

The TableGen fundamentals documentation has moved to a directory on its own
and is now available at :doc:`TableGen/index`. Please, change your links to
that page.
